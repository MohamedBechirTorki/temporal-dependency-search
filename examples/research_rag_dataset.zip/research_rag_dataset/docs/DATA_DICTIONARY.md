# Data dictionary

## data/nodes.jsonl (one JSON object per line)
| field | type | notes |
|---|---|---|
| node_id | string, unique | prefixes: P_ paper, C_ concept, S_ synthetic |
| kind | paper / concept / synthetic_component | |
| label | string | title or concept name |
| provenance | enum | see DATASET_DESCRIPTION |
| first_author, authors_truncated, year, arxiv_id, doi | papers only | doi = 10.48550/arXiv.<id> |
| valid_from, valid_to | ISO-8601 UTC `YYYY-MM-DDTHH:MM:SSZ`, valid_to nullable (open) | valid time |
| recorded_at, recorded_to | same | transaction time |
| note | string/null | |

## data/edges.jsonl
| field | type | notes |
|---|---|---|
| edge_id | string, unique (E001..) | one per record/version |
| relationship_key | string | logical identity shared by versions of a relationship |
| version, supersedes | int, edge_id/null | version chain |
| source, target | node_id | directed source -> target |
| type | CITES, INTRODUCES, EXTENDS, IMPROVES, EVALUATES, COMPARES_WITH, USES, DEPENDS_ON, REPLACES, IDENTIFIES_LIMITATION_OF | |
| provenance | enum | real_documented / modeled_conceptual / modeled_temporal / synthetic_test |
| temporal_basis | publication_date / modeled_scenario | |
| valid_from, valid_to, recorded_at, recorded_to | as above | |
| dependency_version | string/null | e.g. bert-base-uncased, retriever=DPR (2020) |
| evidence | string | short justification |

## ground_truth/expected_queries.json
Expected results computed by verify_ground_truth.py (a reference implementation, no dependencies). Run: `python ground_truth/verify_ground_truth.py <dataset_root>`.
