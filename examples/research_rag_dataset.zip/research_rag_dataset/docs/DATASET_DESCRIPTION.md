# research_rag_dataset

Bitemporal graph corpus on RAG, knowledge graphs and LLM-based retrieval.
**41 nodes** (20 papers, 18 concepts, 3 synthetic) and **65 edge records** (62 currently visible; 3 are superseded/closed versions).

**Schema status:** the format (`data/nodes.jsonl`, `data/edges.jsonl`) was designed WITHOUT inspecting the target importer. It has not been ingested by any application. Field mapping may be needed.

## Papers (bibliographic data: titles/first authors/arXiv IDs; DOI = 10.48550/arXiv.<id>)
| id | title | first author | year | identifier |
|---|---|---|---|---|
| P_FAISS | Billion-scale similarity search with GPUs | Johnson et al. | 2017 | arXiv:1702.08734 |
| P_ATTN | Attention Is All You Need | Vaswani et al. | 2017 | arXiv:1706.03762 |
| P_BERT | BERT: Pre-training of Deep Bidirectional Transformers for Language Understanding | Devlin et al. | 2018 | arXiv:1810.04805 |
| P_SBERT | Sentence-BERT: Sentence Embeddings using Siamese BERT-Networks | Reimers et al. | 2019 | arXiv:1908.10084 |
| P_REALM | REALM: Retrieval-Augmented Language Model Pre-Training | Guu et al. | 2020 | arXiv:2002.08909 |
| P_DPR | Dense Passage Retrieval for Open-Domain Question Answering | Karpukhin et al. | 2020 | arXiv:2004.04906 |
| P_COLBERT | ColBERT: Efficient and Effective Passage Search via Contextualized Late Interaction over BERT | Khattab et al. | 2020 | arXiv:2004.12832 |
| P_RAG | Retrieval-Augmented Generation for Knowledge-Intensive NLP Tasks | Lewis et al. | 2020 | arXiv:2005.11401 |
| P_FID | Leveraging Passage Retrieval with Generative Models for Open Domain Question Answering | Izacard et al. | 2020 | arXiv:2007.01282 |
| P_KILT | KILT: a Benchmark for Knowledge Intensive Language Tasks | Petroni et al. | 2020 | arXiv:2009.02252 |
| P_BEIR | BEIR: A Heterogenous Benchmark for Zero-shot Evaluation of Information Retrieval Models | Thakur et al. | 2021 | arXiv:2104.08663 |
| P_RETRO | Improving language models by retrieving from trillions of tokens | Borgeaud et al. | 2021 | arXiv:2112.04426 |
| P_CONTRIEVER | Unsupervised Dense Information Retrieval with Contrastive Learning | Izacard et al. | 2021 | arXiv:2112.09118 |
| P_ATLAS | Atlas: Few-shot Learning with Retrieval Augmented Language Models | Izacard et al. | 2022 | arXiv:2208.03299 |
| P_HYDE | Precise Zero-Shot Dense Retrieval without Relevance Labels | Gao et al. | 2022 | arXiv:2212.10496 |
| P_LITM | Lost in the Middle: How Language Models Use Long Contexts | Liu et al. | 2023 | arXiv:2307.03172 |
| P_RAGAS | RAGAS: Automated Evaluation of Retrieval Augmented Generation | Es et al. | 2023 | arXiv:2309.15217 |
| P_SELFRAG | Self-RAG: Learning to Retrieve, Generate, and Critique through Self-Reflection | Asai et al. | 2023 | arXiv:2310.11511 |
| P_CRAG | Corrective Retrieval Augmented Generation | Yan et al. | 2024 | arXiv:2401.15884 |
| P_GRAPHRAG | From Local to Global: A Graph RAG Approach to Query-Focused Summarization | Edge et al. | 2024 | arXiv:2404.16130 |

Authors are truncated to the first author (`authors_truncated=true`). `valid_from` of a paper is the first day of its arXiv ID month (month is encoded in the ID; day is a convention, not the real submission day).

## Provenance classes (every node and edge has one)
- `real_documented`: relationship stated/evidenced by the paper itself.
- `modeled_conceptual`: curator-modeled concept dependency (not a claim any paper makes).
- `modeled_temporal`: real relationship whose temporal fields were deliberately set to create a test scenario (late arrival, correction, obsolescence).
- `synthetic_test`: fabricated, NOT research claims (the S_* cycle).

## Temporal test scenarios
| scenario | records |
|---|---|
| Method introduced, later improved | P_RAG -> P_SELFRAG (IMPROVES), P_HYDE IMPROVES P_CONTRIEVER |
| Dependency becomes obsolete | C_RETRIEVE_READ -> C_BM25, valid [2017-06-01, 2020-04-01) |
| Late-arriving info | C_RETRIEVE_READ->C_BM25 recorded 2020-05-01 for validity from 2017; RAG CITES REALM recorded 2023-01-01; Contriever COMPARES_WITH DPR recorded 2022-03-01 |
| Correction after new evidence | E051 DPR REPLACES BM25 (retracted 2021-05-01) -> E052 DPR IMPROVES BM25 (v2, supersedes E051) |
| Dependency version change | C_RAG_PIPELINE -> P_DPR (v1, to 2021-12-01) then -> P_CONTRIEVER (v2) |
| Cycle appearing over time | S_CACHE->S_INDEX->S_REFRESH->S_CACHE; closing edge valid from 2023-06-01 |

## Graph notes
Real part is a DAG (verified: only SCC is the synthetic cycle). Longest dependency chain: P_RAG -> P_DPR -> P_BERT -> C_TRANSFORMER. The synthetic cycle is an isolated component so it cannot contaminate real-graph queries. Edge count is slightly above 60 because versioned edges are separate records.

## Semantics
Valid time and transaction time are half-open [from, to). Edge visible at (V,T) iff valid_from<=V<valid_to AND recorded_at<=T<recorded_to; null = open. Edges are directed source->target; "impact of X" = all nodes that can reach X.
Simulated transaction time: recorded_at equals valid_from except where a scenario says otherwise.

## Limitations
Relationship evidence is from the curator's knowledge of the papers, not re-verified line-by-line against full texts; spot-check before citing. Arxiv-ID-derived dates are month-precision.
