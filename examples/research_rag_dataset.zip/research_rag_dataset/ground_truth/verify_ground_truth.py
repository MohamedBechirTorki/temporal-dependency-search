#!/usr/bin/env python3
"""Independent reference implementation of the dataset's temporal semantics.
Usage: python verify_ground_truth.py [dataset_root]   (recomputes and checks ground_truth/expected_queries.json)"""
import json, sys, os, re
from collections import deque, defaultdict
root = sys.argv[1] if len(sys.argv)>1 else os.path.join(os.path.dirname(os.path.abspath(__file__)),"..")
rd=lambda p:[json.loads(l) for l in open(os.path.join(root,p)) if l.strip()]
nodes,edges=rd("data/nodes.jsonl"),rd("data/edges.jsonl")
P=lambda s:s  # ISO-8601 Z strings compare lexicographically
def visible(e,V=None,T=None):
    if V and not (e["valid_from"]<=V and (e["valid_to"] is None or V<e["valid_to"])): return False
    if T and not (e["recorded_at"]<=T and (e["recorded_to"] is None or T<e["recorded_to"])): return False
    return True
def adj(V=None,T=None,types=None,rev=False):
    g=defaultdict(set)
    for e in edges:
        if visible(e,V,T) and (not types or e["type"] in types):
            a,b=(e["target"],e["source"]) if rev else (e["source"],e["target"])
            g[a].add(b)
    return g
def sp(s,t,**k):
    g=adj(**k); q=deque([[s]]); seen={s}
    while q:
        p=q.popleft()
        if p[-1]==t: return p
        for n in sorted(g[p[-1]]):
            if n not in seen: seen.add(n); q.append(p+[n])
def reach(s,rev=False,**k):
    g=adj(rev=rev,**k); seen={s}; q=deque([s])
    while q:
        for n in g[q.popleft()]:
            if n not in seen: seen.add(n); q.append(n)
    return sorted(seen-{s})
def scc(**k):
    g=adj(**k); idx={};low={};st=[];on=set();out=[];c=[0]
    sys.setrecursionlimit(10000)
    def sc(v):
        idx[v]=low[v]=c[0];c[0]+=1;st.append(v);on.add(v)
        for w in g[v]:
            if w not in idx: sc(w);low[v]=min(low[v],low[w])
            elif w in on: low[v]=min(low[v],idx[w])
        if low[v]==idx[v]:
            comp=[]
            while True:
                w=st.pop();on.discard(w);comp.append(w)
                if w==v:break
            out.append(sorted(comp))
    for n in [x["node_id"] for x in nodes]:
        if n not in idx: sc(n)
    return sorted(x for x in out if len(x)>1 or x[0] in g[x[0]])
def outn(n,**k): return sorted(adj(**k)[n])
def inn(n,**k): return sorted(adj(rev=True,**k)[n])
def etypes(s,t,**k): return sorted((e["edge_id"],e["type"],e["version"]) for e in edges if e["source"]==s and e["target"]==t and visible(e,**k))
NOW="2026-11-25T00:00:00Z"
DEP={"USES","DEPENDS_ON"}
PA=lambda x:x
Q={
"DEPONLY_shortest_path_RAG_to_TRANSFORMER_now":sp("P_RAG","C_TRANSFORMER",V=NOW,T=NOW,types=DEP),
"DEPONLY_shortest_path_ATLAS_to_TRANSFORMER_now":sp("P_ATLAS","C_TRANSFORMER",V=NOW,T=NOW,types=DEP),
"DEPONLY_outgoing_P_DPR_now":sorted(adj(V=NOW,T=NOW,types=DEP)["P_DPR"]),
"DEPONLY_incoming_P_BERT_now":sorted(adj(V=NOW,T=NOW,types=DEP,rev=True)["P_BERT"]),
"DEPONLY_impact_P_BERT_now":reach("P_BERT",rev=True,V=NOW,T=NOW,types=DEP),
"DEPONLY_impact_P_BERT_valid2020-06-01_known2020-06-01":reach("P_BERT",rev=True,V="2020-06-01T00:00:00Z",T="2020-06-01T00:00:00Z",types=DEP),
"DEPONLY_impact_P_BERT_valid2023-01-01_known2023-01-01":reach("P_BERT",rev=True,V="2023-01-01T00:00:00Z",T="2023-01-01T00:00:00Z",types=DEP),
"DEPONLY_impact_C_TRANSFORMER_now":reach("C_TRANSFORMER",rev=True,V=NOW,T=NOW,types=DEP),
"DEPONLY_impact_P_CONTRIEVER_now":reach("P_CONTRIEVER",rev=True,V=NOW,T=NOW,types=DEP),
"DEPONLY_impact_P_CONTRIEVER_valid2021-06-01_known2021-06-01":reach("P_CONTRIEVER",rev=True,V="2021-06-01T00:00:00Z",T="2021-06-01T00:00:00Z",types=DEP),
"DEPONLY_cycles_now":scc(V=NOW,T=NOW,types=DEP),
"shortest_path_ATLAS_to_TRANSFORMER_now":sp("P_ATLAS","C_TRANSFORMER",V=NOW,T=NOW),
"shortest_path_RAG_to_TRANSFORMER_now":sp("P_RAG","C_TRANSFORMER",V=NOW,T=NOW),
"shortest_path_CRAG_to_BM25_now":sp("P_CRAG","C_BM25",V=NOW,T=NOW),
"outgoing_P_RAG_now":outn("P_RAG",V=NOW,T=NOW),
"incoming_P_DPR_now":inn("P_DPR",V=NOW,T=NOW),
"incoming_P_BERT_now":inn("P_BERT",V=NOW,T=NOW),
"impact_C_TRANSFORMER_now(all upstream dependents)":reach("C_TRANSFORMER",rev=True,V=NOW,T=NOW),
"impact_P_BERT_now":reach("P_BERT",rev=True,V=NOW,T=NOW),
"impact_P_BERT_valid2020-06-01_known2020-06-01":reach("P_BERT",rev=True,V="2020-06-01T00:00:00Z",T="2020-06-01T00:00:00Z"),
"impact_P_BERT_valid2023-01-01_known2023-01-01":reach("P_BERT",rev=True,V="2023-01-01T00:00:00Z",T="2023-01-01T00:00:00Z"),
"impact_P_CONTRIEVER_dependents_now":reach("P_CONTRIEVER",rev=True,V=NOW,T=NOW),
"cycles_now":scc(V=NOW,T=NOW),
"cycles_valid2023-03-01":scc(V="2023-03-01T00:00:00Z",T=NOW),
"cycles_valid2023-12-01":scc(V="2023-12-01T00:00:00Z",T=NOW),
"valid_time_C_RETRIEVE_READ_deps_valid2019-01-01_known_now":outn("C_RETRIEVE_READ",V="2019-01-01T00:00:00Z",T=NOW),
"valid_time_C_RETRIEVE_READ_deps_valid2021-01-01_known_now":outn("C_RETRIEVE_READ",V="2021-01-01T00:00:00Z",T=NOW),
"txn_time_C_RETRIEVE_READ_deps_valid2019-01-01_known2019-06-01(late arrival: nothing known yet)":outn("C_RETRIEVE_READ",V="2019-01-01T00:00:00Z",T="2019-06-01T00:00:00Z"),
"txn_time_DPR->BM25_valid2020-06-01_known2020-12-01":etypes("P_DPR","C_BM25",V="2020-06-01T00:00:00Z",T="2020-12-01T00:00:00Z"),
"txn_time_DPR->BM25_valid2020-06-01_known2021-12-01(after correction)":etypes("P_DPR","C_BM25",V="2020-06-01T00:00:00Z",T="2021-12-01T00:00:00Z"),
"late_arrival_RAG->REALM_valid2020-06-01_known2021-01-01":etypes("P_RAG","P_REALM",V="2020-06-01T00:00:00Z",T="2021-01-01T00:00:00Z"),
"late_arrival_RAG->REALM_valid2020-06-01_known2023-02-01":etypes("P_RAG","P_REALM",V="2020-06-01T00:00:00Z",T="2023-02-01T00:00:00Z"),
"dependency_version_C_RAG_PIPELINE_retriever_valid2021-01-01":[(e["target"],e["dependency_version"]) for e in edges if e["source"]=="C_RAG_PIPELINE" and e["relationship_key"].endswith("retriever") and visible(e,V="2021-01-01T00:00:00Z",T=NOW)],
"dependency_version_C_RAG_PIPELINE_retriever_valid2022-06-01":[(e["target"],e["dependency_version"]) for e in edges if e["source"]=="C_RAG_PIPELINE" and e["relationship_key"].endswith("retriever") and visible(e,V="2022-06-01T00:00:00Z",T=NOW)],
"graph_size_valid2020-06-01_known2020-06-01":{"edges":sum(visible(e,"2020-06-01T00:00:00Z","2020-06-01T00:00:00Z") for e in edges)},
"graph_size_now":{"edges":sum(visible(e,NOW,NOW) for e in edges)},
}
# ---------- structural validation ----------
errs=[]
ids=[n["node_id"] for n in nodes]; eids=[e["edge_id"] for e in edges]
if len(ids)!=len(set(ids)):errs.append("dup node ids")
if len(eids)!=len(set(eids)):errs.append("dup edge ids")
ISO=re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$")
S=set(ids); byid={e["edge_id"]:e for e in edges}
for r in nodes+edges:
    for f in ("valid_from","valid_to","recorded_at","recorded_to"):
        v=r.get(f)
        if v is not None and not ISO.match(v): errs.append(f"bad ts {f} {r.get('edge_id',r.get('node_id'))}")
    if r["valid_to"] and r["valid_to"]<=r["valid_from"]: errs.append("bad valid interval")
    if r["recorded_to"] and r["recorded_to"]<=r["recorded_at"]: errs.append("bad txn interval")
for e in edges:
    if e["source"] not in S or e["target"] not in S: errs.append("dangling "+e["edge_id"])
    if e["source"]==e["target"]: errs.append("self loop")
    if e["supersedes"] and e["supersedes"] not in byid: errs.append("bad supersedes")
    if e["provenance"]=="synthetic_test" and not (e["source"].startswith("S_") and e["target"].startswith("S_")): errs.append("synthetic edge touching real node")
    if e["recorded_at"]<e["valid_from"] and e["provenance"]=="real_documented": errs.append("recorded before valid "+e["edge_id"])
assert not errs,errs
real_cycles=scc(V=NOW,T=NOW)
assert all(all(x.startswith("S_") for x in c) for c in real_cycles),"unexpected non-synthetic cycle"
out=os.path.join(root,"ground_truth/expected_queries.json")
if "--write" in sys.argv:
    json.dump({"semantics":"edge visible at (V,T) iff valid_from<=V<valid_to(or open) AND recorded_at<=T<recorded_to(or open); edges directed source->target; 'impact' = all nodes that can reach X; queries are over ALL edge types unless the key starts with DEPONLY_ (then only USES and DEPENDS_ON are traversed)","queries":Q},open(out,"w"),indent=2)
    print("written")
else:
    exp=json.load(open(out))["queries"]
    assert exp==json.loads(json.dumps(Q)),"ground truth mismatch"
    print("OK: structure valid and ground truth reproduced;",len(nodes),"nodes",len(edges),"edges")
