Sample temporal dependency graph: 7 nodes, 8 directed edges.
Historical edge: legacy-service -> order-service, valid from
2024-02-01T00:00:00Z until 2024-08-01T00:00:00Z.

Illustrative JSON schema: nodes[{id,type,name}], edges[{id,source,target,
type,valid_from,valid_to}]. Your application's importer may expect a
different schema or ZIP layout; adapt if it reports a schema error.
